import cv2
import torch
from ultralytics import YOLO
from torchvision import transforms
from PIL import Image
import numpy as np
from main import CRNN, Config, decode  # Replace with your actual module name
import os
from glob import glob
import csv


# Load YOLOv8 model
yolo_model = YOLO("best.pt")

# Load CRNN model
cfg = Config()
crnn_model = CRNN(cfg.alphabet).to(cfg.device)
crnn_model.load_state_dict(torch.load("crnn_plate_recognition6.pth", map_location=cfg.device))
crnn_model.eval()

# Image transform for CRNN (matches your ResizeNormalize logic without augmentation)
transform = transforms.Compose([
    transforms.Resize(cfg.img_size[::-1]),  # (width, height)
    transforms.ToTensor()
])

def recognize_text(crop):
    """Runs CRNN OCR on a cropped image (OpenCV RGB)."""
    # Resize using OpenCV to match (320, 64)
    image = cv2.resize(np.array(crop), cfg.img_size, interpolation=cv2.INTER_AREA)

    # Normalize like training code
    image = image.astype(np.float32) / 255.0
    image = torch.from_numpy(image).permute(2, 0, 1).unsqueeze(0).to(cfg.device)

    with torch.no_grad():
        preds = crnn_model(image)
        texts = decode(preds, cfg.alphabet)
    return texts[0] if texts else ""


def detect_and_ocr(image_path):
    results = yolo_model(image_path)[0]
    image = cv2.imread(image_path)
    plates = []

    for i, box in enumerate(results.boxes):
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        label = int(box.cls[0])
        class_name = results.names[label]

        if class_name == "car_plate":  # Only apply CRNN to detected plates
            plate_crop = image[y1:y2, x1:x2]
            pil_crop = Image.fromarray(cv2.cvtColor(plate_crop, cv2.COLOR_BGR2RGB))

            os.makedirs("output/crops", exist_ok=True)
            crop_filename = os.path.basename(image_path).replace(".jpg", f"_crop_{i}.jpg")
            crop_path = os.path.join("output/crops", crop_filename)
            cv2.imwrite(crop_path, cv2.resize(np.array(pil_crop), (320, 64)))
            print(f"[🖼️] Saved cropped plate to: {crop_path}")


            text = recognize_text(pil_crop)

            plates.append((text, (x1, y1, x2, y2)))
            print(f"  🟩 Plate Detected: {text}")

            # Draw
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(image, text, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

        else:
            # Optional: draw car boxes too (not used for OCR)
            cv2.rectangle(image, (x1, y1), (x2, y2), (255, 0, 0), 2)
            cv2.putText(image, class_name, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)

    # Save image
    os.makedirs("output", exist_ok=True)
    output_path = os.path.join("output", os.path.basename(image_path))
    cv2.imwrite(output_path, image)
    print(f"[✅] Saved annotated image: {output_path}")

    # Append predictions to CSV
    if plates:
        with open("output/results.csv", "a", newline='') as csvfile:
            writer = csv.writer(csvfile)
            for plate_text, _ in plates:
                writer.writerow([os.path.basename(image_path), plate_text])

    return plates

if __name__ == "__main__":
    image_dir = r"D:\Programming\2025 Sem1\Intelligent System\Program\YOLO+CRNN\Dataset"
    image_paths = glob(os.path.join(image_dir, "*.jpg"))  # or "*.png" if your images are in PNG format

    for path in sorted(image_paths):
        print(f"🔍 Processing {os.path.basename(path)}")
        try:
            detect_and_ocr(path)  # Pass one image path at a time
        except Exception as e:
            print(f"[ERROR] Failed on {path}: {e}")
