import os
import cv2
import torch
import numpy as np
import xml.etree.ElementTree as ET
from PIL import Image
from collections import defaultdict
from ultralytics import YOLO
from torchvision import transforms
from main import CRNN, Config, decode
from jiwer import wer, cer

# === CONFIG ===
IMAGE_DIR = r"D:\Programming\2025 Sem1\Intelligent System\Program\YOLO+CRNN\Dataset\images"
XML_LABEL_DIR = r"D:\Programming\2025 Sem1\Intelligent System\Program\YOLO+CRNN\Dataset\label"
TEXT_LABEL_FILE = r"D:\Programming\2025 Sem1\Intelligent System\Program\YOLO+CRNN\Dataset\tlabel\text_label.txt"

IOU_THRESHOLD = 0.5

# === Load models ===
yolo_model = YOLO("best.pt")
cfg = Config()
crnn_model = CRNN(cfg.alphabet).to(cfg.device)
crnn_model.load_state_dict(torch.load("crnn_plate_recognition6.pth", map_location=cfg.device))
crnn_model.eval()

# === Helper to recognize text ===
def recognize_text(crop):
    image = cv2.resize(np.array(crop), cfg.img_size, interpolation=cv2.INTER_AREA)
    image = image.astype(np.float32) / 255.0
    image = torch.from_numpy(image).permute(2, 0, 1).unsqueeze(0).to(cfg.device)
    with torch.no_grad():
        preds = crnn_model(image)
        texts = decode(preds, cfg.alphabet)
    return texts[0] if texts else ""

# === IoU calculation ===
def compute_iou(boxA, boxB):
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])
    interArea = max(0, xB - xA) * max(0, yB - yA)
    boxAArea = max(1, (boxA[2] - boxA[0]) * (boxA[3] - boxA[1]))
    boxBArea = max(1, (boxB[2] - boxB[0]) * (boxB[3] - boxB[1]))
    return interArea / float(boxAArea + boxBArea - interArea)

# === Load OCR text labels ===
ocr_labels = defaultdict(list)
with open(TEXT_LABEL_FILE, "r", encoding="utf-8") as f:
    for i, line in enumerate(f, 1):
        line = line.strip()
        if not line:
            continue
        parts = line.split("|")
        if len(parts) != 2:
            print(f"⚠️ Skipping malformed line {i}: {repr(line)}")
            continue
        img, plate = parts
        normalized_img = img.strip().replace(" ", "")
        ocr_labels[normalized_img].append(plate)

# === Evaluation ===
total_plates = 0
correct_detections = 0
ocr_correct = 0
cer_list = []
wer_list = []

for fname in os.listdir(IMAGE_DIR):
    if not fname.endswith((".jpg", ".png")):
        continue
    img_path = os.path.join(IMAGE_DIR, fname)
    label_path = os.path.join(XML_LABEL_DIR, os.path.splitext(fname)[0] + ".xml")
    if not os.path.exists(label_path):
        continue

    img = cv2.imread(img_path)
    results = yolo_model(img)[0]

    # Load ground truth bounding boxes
    gt_boxes = []
    tree = ET.parse(label_path)
    root = tree.getroot()
    for obj in root.findall("object"):
        name = obj.find("name").text
        if name.lower() == "carplate" or name.lower() == "car_plate":
            bndbox = obj.find("bndbox")
            xmin = int(bndbox.find("xmin").text)
            ymin = int(bndbox.find("ymin").text)
            xmax = int(bndbox.find("xmax").text)
            ymax = int(bndbox.find("ymax").text)
            gt_boxes.append([xmin, ymin, xmax, ymax])

    normalized_fname = fname.replace(" ", "")
    gt_texts = ocr_labels[normalized_fname] if normalized_fname in ocr_labels else []

    # Match YOLO detections
    for box in results.boxes:
        cls = int(box.cls[0])
        conf = float(box.conf[0])
        label = results.names[cls]
        if label != "car_plate":
            continue
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        pred_box = [x1, y1, x2, y2]

        matched = False
        for gt_box in gt_boxes:
            iou = compute_iou(pred_box, gt_box)
            if iou >= IOU_THRESHOLD:
                correct_detections += 1
                crop = img[gt_box[1]:gt_box[3], gt_box[0]:gt_box[2]]
                pil_crop = Image.fromarray(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB))
                pred_text = recognize_text(pil_crop).strip()

                match_found = False
                for gt in gt_texts:
                    print(f"📸 Image: {fname}")
                    print(f"🔠 Predicted: {pred_text}")
                    print(f"✅ Ground Truth: {gt}")
                    if pred_text.lower() == gt.lower():
                        ocr_correct += 1
                        match_found = True
                        print("🎯 Match ✅\n")
                        break
                    else:
                        cer_score = cer(gt.strip(), pred_text.strip())
                        wer_score = wer(gt.strip(), pred_text.strip())
                        cer_list.append(cer_score)
                        wer_list.append(wer_score)
                        print(f"❌ Mismatch - CER: {cer_score:.4f}, WER: {wer_score:.4f}\n")

                else:
                    for gt in gt_texts:
                        cer_list.append(cer(gt.strip(), pred_text.strip()))
                        wer_list.append(wer(gt.strip(), pred_text.strip()))
                matched = True
                break
        if matched:
            total_plates += 1

# === Final report ===
avg_cer = np.mean(cer_list) if cer_list else 0.0
avg_wer = np.mean(wer_list) if wer_list else 0.0
detection_acc = correct_detections / total_plates if total_plates else 0.0
ocr_acc = ocr_correct / total_plates if total_plates else 0.0
combined_score = (detection_acc + ocr_acc) / 2

print(f"\n🧪 Evaluation Results on {total_plates} plates:")
print(f"📦 Detection Accuracy         : {detection_acc:.2%}")
print(f"🔠 OCR Exact Match Accuracy   : {ocr_acc:.2%}")
print(f"📉 Average CER (Character)    : {avg_cer:.4f}")
print(f"📉 Average WER (Word)         : {avg_wer:.4f}")
print(f"✅ Combined System Score      : {combined_score:.2%}")
