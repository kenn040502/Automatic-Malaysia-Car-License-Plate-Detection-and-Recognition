import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import cv2
import torch
from ultralytics import YOLO
from torchvision import transforms
import numpy as np
from main import CRNN, Config, decode
import os

# Load YOLOv8 and CRNN models
yolo_model = YOLO("best.pt")

cfg = Config()
crnn_model = CRNN(cfg.alphabet).to(cfg.device)
crnn_model.load_state_dict(torch.load("crnn_plate_recognition6.pth", map_location=cfg.device))
crnn_model.eval()

transform = transforms.Compose([
    transforms.Resize(cfg.img_size[::-1]),
    transforms.ToTensor()
])

def recognize_text(crop):
    image = cv2.resize(np.array(crop), cfg.img_size, interpolation=cv2.INTER_AREA)
    image = image.astype(np.float32) / 255.0
    image = torch.from_numpy(image).permute(2, 0, 1).unsqueeze(0).to(cfg.device)
    with torch.no_grad():
        preds = crnn_model(image)
        texts = decode(preds, cfg.alphabet)
    return texts[0] if texts else ""

def detect_from_frame(frame):
    results = yolo_model(frame)[0]
    for box in results.boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        label = int(box.cls[0])
        class_name = results.names[label]
        font = cv2.FONT_HERSHEY_SIMPLEX

        if class_name == "car_plate":
            crop = frame[y1:y2, x1:x2]
            pil_crop = Image.fromarray(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB))
            text = recognize_text(pil_crop)

            # Draw bounding box
            cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 247, 0), 5)

            # Dynamically scale font based on plate width
            plate_width = x2 - x1
            font_scale = max(0.5, plate_width / 180)
            thickness = max(1, int(plate_width / 100))

            # Text size
            (text_width, text_height), baseline = cv2.getTextSize(text, font, font_scale, thickness)
            rect_x1 = x1
            rect_y1 = y1 - text_height - baseline - 10
            rect_x2 = x1 + text_width
            rect_y2 = y1

            # Draw background and text
            cv2.rectangle(frame, (rect_x1, rect_y1), (rect_x2, rect_y2), (0, 0, 0), cv2.FILLED)
            cv2.putText(frame, text, (x1, y1 - 10), font, font_scale, (255, 255, 255), thickness, cv2.LINE_AA)

        else:
            # For car bounding boxes
            cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 255, 255), 3)
            font_scale = max(0.5, (x2 - x1) / 200)
            thickness = max(1, int((x2 - x1) / 150))
            cv2.putText(frame, class_name, (x1, y1 - 10), font, font_scale, (255, 255, 255), thickness, cv2.LINE_AA)
    return frame


class PlateRecognizerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Car Plate Recognition")
        self.label = tk.Label(root, text="Upload an image or video for recognition")
        self.label.pack()

        self.canvas = tk.Label(root)
        self.canvas.pack()

        self.btn_frame = tk.Frame(root)
        self.btn_frame.pack()

        self.img_btn = tk.Button(self.btn_frame, text="Upload Image", command=self.upload_image)
        self.img_btn.pack(side=tk.LEFT, padx=10)

        self.vid_btn = tk.Button(self.btn_frame, text="Upload Video", command=self.upload_video)
        self.vid_btn.pack(side=tk.LEFT, padx=10)

    def upload_image(self):
        path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.jpeg *.png")])
        if path:
            img = cv2.imread(path)
            annotated = detect_from_frame(img)
            rgb_img = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
            pil_img = Image.fromarray(rgb_img)

            # Resize for GUI display
            max_width, max_height = 800, 600
            pil_img.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
            imgtk = ImageTk.PhotoImage(pil_img)
            self.canvas.configure(image=imgtk)
            self.canvas.image = imgtk
            self.label.config(text=f"Processed: {os.path.basename(path)}")


    def upload_video(self):
        path = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov")])
        if not path:
            return

        cap = cv2.VideoCapture(path)

        def update_frame():
            ret, frame = cap.read()
            if not ret:
                cap.release()
                return

            frame = detect_from_frame(frame)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img_pil = Image.fromarray(rgb)

            # Resize for GUI display
            max_width, max_height = 1280, 720
            img_pil.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
            imgtk = ImageTk.PhotoImage(img_pil)

            self.canvas.configure(image=imgtk)
            self.canvas.image = imgtk
            self.root.after(30, update_frame)  # ~33 FPS

        update_frame()  # start video loop


# Launch the app
if __name__ == "__main__":
    root = tk.Tk()
    app = PlateRecognizerApp(root)
    root.mainloop()
