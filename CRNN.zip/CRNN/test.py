import os
import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
from tqdm import tqdm
import matplotlib.pyplot as plt
import time
import jiwer
from jiwer import compute_measures 
import pickle
import json
import pandas as pd
from datetime import datetime
from torchvision import transforms
from main import CRNN, decode, Config, ResizeNormalize, PlateDataset, collate_fn

def test():
    cfg = Config()
    model = CRNN(cfg.alphabet).to(cfg.device)
    model.load_state_dict(torch.load("crnn_plate_recognition6.pth", map_location=cfg.device))
    model.eval()

    transform = ResizeNormalize(cfg.img_size, augment=False)
    test_set = PlateDataset(cfg.test_dir, cfg.test_label_dir, cfg.alphabet, transform)
    test_loader = DataLoader(test_set, batch_size=cfg.batch_size, shuffle=False, collate_fn=collate_fn)

    total_correct_chars = 0
    total_chars = 0
    total_correct_words = 0
    total_words = 0
    exact_matches = 0

    all_truths = []
    all_preds = []

    with torch.no_grad():
        for batch in tqdm(test_loader, desc="Testing"):
            imgs = batch['image'].to(cfg.device)
            texts = batch['text']
            outputs = model(imgs)
            pred_texts = decode(outputs, cfg.alphabet)

            for pred, truth in zip(pred_texts, texts):
                # Character accuracy statistics
                max_len = max(len(pred), len(truth))
                total_chars += max_len
                total_correct_chars += sum(1 for p, t in zip(pred, truth) if p == t)

                # Word accuracy statistics
                total_words += 1
                if pred == truth:
                    total_correct_words += 1
                    exact_matches += 1

                all_truths.append(truth)
                all_preds.append(pred)

    # Accuracy metrics
    total_examples = len(all_truths)
    char_accuracy = total_correct_chars / max(1, total_chars)
    word_accuracy = total_correct_words / max(1, total_words)
    exact_match_accuracy = exact_matches / max(1, total_examples)

        # === Aggregate CER and WER ===
    measures_cer = jiwer.compute_measures(all_truths, all_preds)
    cer_aggregate = measures_cer['wer']

    def to_word_list(s):
        return list(s) if ' ' not in s else s.split()

    truth_words = [' '.join(to_word_list(s)) for s in all_truths]
    pred_words = [' '.join(to_word_list(s)) for s in all_preds]

    measures_wer = jiwer.compute_measures(truth_words, pred_words)
    wer_aggregate = measures_wer['wer']

    # === Average CER and WER per sample ===
    import Levenshtein

    cer_list = []
    for t, p in zip(all_truths, all_preds):
        t_clean = t.replace(" ", "").upper()
        p_clean = p.replace(" ", "").upper()
        if len(t_clean) == 0:
            cer_list.append(0.0)
        else:
            dist = Levenshtein.distance(p_clean, t_clean)
            cer_list.append(dist / len(t_clean))

    cer_avg = np.mean(cer_list)

    wer_list = [
        jiwer.compute_measures(
            ' '.join(to_word_list(t)),
            ' '.join(to_word_list(p))
        )['wer']
        for t, p in zip(all_truths, all_preds)
    ]
    cer_avg = np.mean(cer_list)
    wer_avg = np.mean(wer_list)


    print("\n====== 📊 Evaluation Summary ======")
    print(f"Total Samples             : {total_examples}")
    print(f"Exact Matches             : {exact_matches}")
    print(f"Exact Match Accuracy      : {exact_match_accuracy:.4f}")
    print(f"Character Accuracy        : {char_accuracy:.4f}")
    print(f"Word Accuracy             : {word_accuracy:.4f}")
    print(f"CER (Aggregate)           : {cer_aggregate:.4f}")
    print(f"WER (Aggregate)           : {wer_aggregate:.4f}")
    print(f"CER (Average Per Sample)  : {cer_avg:.4f}")
    print(f"WER (Average Per Sample)  : {wer_avg:.4f}")


    # === Print Examples ===
    print("\n📝 Sample Predictions:")
    for i, (truth, pred) in enumerate(list(zip(all_truths, all_preds))[:10]):
        print(f"Sample {i+1}: True='{truth}', Pred='{pred}', {'✅ Correct' if truth == pred else '❌ Incorrect'}")

    return (
        total_examples,
        exact_matches,
        exact_match_accuracy,
        char_accuracy,
        word_accuracy,
        cer_aggregate,
        wer_aggregate,
        cer_avg,
        wer_avg,
        list(zip(all_truths, all_preds))
    )

if __name__ == "__main__":
    results = test()
