import os
import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
from tqdm import tqdm
import matplotlib.pyplot as plt
import time
import jiwer
from jiwer import compute_measures 
import pickle

# ===== Config =====
class Config:
    base_dir = "OCR_Dataset"

    train_dir = os.path.join(base_dir, "train")
    train_label_dir = os.path.join(base_dir, "train_label")

    val_dir = os.path.join(base_dir, "val")
    val_label_dir = os.path.join(base_dir, "val_label")

    test_dir = os.path.join(base_dir, "test")
    test_label_dir = os.path.join(base_dir, "test_label")

    alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    img_size = (320, 64)
    batch_size = 16
    lr = 1e-4
    epochs = 70
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ===== Dataset =====
class PlateDataset(Dataset):
    def __init__(self, image_dir, label_dir, alphabet, transform=None):
        self.image_dir = Path(image_dir)
        self.label_dir = Path(label_dir)
        self.image_paths = list(self.image_dir.glob("*.jpg")) + list(self.image_dir.glob("*.png"))
        self.alphabet = alphabet
        self.transform = transform

        self.image_paths = [img for img in self.image_paths if (self.label_dir / (img.stem + ".txt")).exists()]
        print(f"[INFO] Loaded {len(self.image_paths)} images from {image_dir}")

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        image = cv2.imread(str(img_path))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        label_path = self.label_dir / (img_path.stem + ".txt")
        with open(label_path, "r", encoding="utf-8") as f:
            text = f.read().strip().upper()

        if not all(c in self.alphabet for c in text):
            raise ValueError(f"[ERROR] Invalid characters in: {label_path}")

        seq = [self.alphabet.find(c) + 1 for c in text]

        sample = {
            "image": image,
            "text": text,
            "seq": seq,
            "seq_len": len(seq)
        }

        if self.transform:
            sample = self.transform(sample)
        return sample

# ===== Transform =====
class ResizeNormalize:
    def __init__(self, size, augment=False):
        self.size = size
        self.augment = augment

    def __call__(self, sample):
        image = sample["image"]
        image = cv2.resize(image, self.size, interpolation=cv2.INTER_AREA)
        if self.augment:
            if np.random.rand() < 0.5:
                image = cv2.GaussianBlur(image, (3, 3), 0)
            if np.random.rand() < 0.5:
                alpha = np.random.uniform(0.8, 1.2)
                beta = np.random.randint(-10, 10)
                image = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)
        image = image.astype(np.float32) / 255.0
        image = torch.from_numpy(image).permute(2, 0, 1)
        return {
            "image": image,
            "text": sample["text"],
            "seq": sample["seq"],
            "seq_len": sample["seq_len"]
        }

# ===== Collate =====
def collate_fn(batch):
    images = torch.stack([item['image'] for item in batch])
    texts = [item['text'] for item in batch]
    seq_lens = torch.IntTensor([item['seq_len'] for item in batch])
    max_len = max(seq_lens)
    seqs = torch.zeros(len(batch), max_len, dtype=torch.long)
    for i, item in enumerate(batch):
        seqs[i, :len(item['seq'])] = torch.LongTensor(item['seq'])
    return {
        'image': images,
        'text': texts,
        'seq': seqs,
        'seq_len': seq_lens
    }

# ===== Model =====
class CRNN(nn.Module):
    def __init__(self, alphabet):
        super().__init__()
        self.alphabet = alphabet
        self.cnn = nn.Sequential(
            nn.Conv2d(3, 64, 3, 1, 1), nn.BatchNorm2d(64), nn.ReLU(), nn.MaxPool2d(2, 2),
            nn.Conv2d(64, 128, 3, 1, 1), nn.BatchNorm2d(128), nn.ReLU(), nn.MaxPool2d(2, 2),
            nn.Conv2d(128, 256, 3, 1, 1), nn.BatchNorm2d(256), nn.ReLU(),
            nn.Conv2d(256, 256, 3, 1, 1), nn.BatchNorm2d(256), nn.ReLU(), nn.MaxPool2d((2, 1), (2, 1)),
            nn.Conv2d(256, 512, 3, 1, 1), nn.BatchNorm2d(512), nn.ReLU(),
            nn.Conv2d(512, 512, 3, 1, 1), nn.BatchNorm2d(512), nn.ReLU(), nn.MaxPool2d((2, 1), (2, 1)),
            nn.Conv2d(512, 512, 2, 1, 0), nn.BatchNorm2d(512), nn.ReLU()
        )
        self.rnn = nn.LSTM(512, 256, 2, bidirectional=True, dropout=0.3)
        self.fc = nn.Linear(512, len(alphabet) + 1)

    def forward(self, x):
        x = self.cnn(x)
        x = F.adaptive_avg_pool2d(x, (1, None)).squeeze(2)
        x = x.permute(2, 0, 1)
        x, _ = self.rnn(x)
        return self.fc(x)

def decode(pred, alphabet):
    pred = pred.permute(1, 0, 2)
    pred_indices = pred.argmax(2)
    results = []
    for raw_pred in pred_indices:
        prev_char = None
        decoded = []
        for i in raw_pred.cpu().numpy():
            if i != 0 and i != prev_char:
                decoded.append(alphabet[i - 1])
            prev_char = i
        results.append(''.join(decoded))
    return results

# ===== Train and Test =====
def train():
    cfg = Config()
    
    # Initialize history dictionary
    history = {
        'train_loss': [],
        'val_loss': [],
        'train_acc': [],  # Training accuracy
        'val_acc': [],    # Validation accuracy
        'lr': [],         # Learning rate history
        'best_val_loss': float('inf'),
        'best_epoch': 0
    }

    model = CRNN(cfg.alphabet).to(cfg.device)
    transform = ResizeNormalize(cfg.img_size, augment=True)
    train_set = PlateDataset(cfg.train_dir, cfg.train_label_dir, cfg.alphabet, transform)
    val_set = PlateDataset(cfg.val_dir, cfg.val_label_dir, cfg.alphabet, transform)
    
    train_loader = DataLoader(train_set, batch_size=cfg.batch_size, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(val_set, batch_size=cfg.batch_size, shuffle=False, collate_fn=collate_fn)
    
    optimizer = optim.Adam(model.parameters(), lr=cfg.lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', patience=2)
    
    # Early stopping parameters
    early_stop_patience = 8
    early_stop_counter = 0
    
    for epoch in range(cfg.epochs):
        model.train()
        total_loss, total_correct, total_chars = 0, 0, 0
        
        # ===== Training Phase =====
        for batch in tqdm(train_loader, desc=f"Epoch {epoch+1}/{cfg.epochs}"):
            imgs = batch['image'].to(cfg.device)
            seqs = batch['seq'].to(cfg.device)
            seq_lens = batch['seq_len'].to(cfg.device)
            
            # Forward pass
            outputs = model(imgs)
            log_probs = F.log_softmax(outputs, dim=2)
            input_lengths = torch.full((outputs.size(1),), outputs.size(0), dtype=torch.long).to(cfg.device)
            
            # Calculate loss
            loss = F.ctc_loss(log_probs, seqs, input_lengths, seq_lens, zero_infinity=True)
            
            # Backward pass
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            # Record data
            total_loss += loss.item()
            
            # Calculate training accuracy
            pred_texts = decode(outputs, cfg.alphabet)
            for pred, truth in zip(pred_texts, batch['text']):
                total_chars += max(len(pred), len(truth))
                total_correct += sum(1 for p, t in zip(pred, truth) if p == t)
        
        # Calculate average training metrics
        avg_train_loss = total_loss / len(train_loader)
        train_acc = total_correct / max(1, total_chars)
        history['train_loss'].append(avg_train_loss)
        history['train_acc'].append(train_acc)
        history['lr'].append(optimizer.param_groups[0]['lr'])
        
        print(f"\nTrain Loss: {avg_train_loss:.4f} | Train Acc: {train_acc:.4f}")
        
        # ===== Validation Phase =====
        model.eval()
        val_loss, val_correct, val_chars = 0, 0, 0
        val_samples = []  # Store some validation samples
        
        with torch.no_grad():
            for batch in val_loader:
                imgs = batch['image'].to(cfg.device)
                seqs = batch['seq'].to(cfg.device)
                seq_lens = batch['seq_len'].to(cfg.device)
                
                outputs = model(imgs)
                log_probs = F.log_softmax(outputs, dim=2)
                input_lengths = torch.full((outputs.size(1),), outputs.size(0), dtype=torch.long).to(cfg.device)
                
                # Calculate validation loss
                loss = F.ctc_loss(log_probs, seqs, input_lengths, seq_lens, zero_infinity=True)
                val_loss += loss.item()
                
                # Calculate validation accuracy
                pred_texts = decode(outputs, cfg.alphabet)
                for pred, truth in zip(pred_texts, batch['text']):
                    val_chars += max(len(pred), len(truth))
                    val_correct += sum(1 for p, t in zip(pred, truth) if p == t)
                    
                    # Store some samples
                    if len(val_samples) < 3:
                        val_samples.append((truth, pred))
        
        # Calculate average validation metrics
        avg_val_loss = val_loss / len(val_loader)
        val_acc = val_correct / max(1, val_chars)
        history['val_loss'].append(avg_val_loss)
        history['val_acc'].append(val_acc)
        
        print(f"Val Loss: {avg_val_loss:.4f} | Val Acc: {val_acc:.4f}")
        print("Validation Samples:")
        for truth, pred in val_samples:
            print(f"  True: {truth.ljust(10)} | Pred: {pred.ljust(10)} | {'Correct' if truth == pred else 'Incorrect'}")
        
        # Update learning rate
        scheduler.step(avg_val_loss)
        
        # ===== Model Saving and Early Stopping =====
        if avg_val_loss < history['best_val_loss']:
            history['best_val_loss'] = avg_val_loss
            history['best_epoch'] = epoch + 1
            early_stop_counter = 0
            torch.save(model.state_dict(), 'best_model.pth')
            print("Model improved and saved!")
        else:
            early_stop_counter += 1
            print(f"No improvement for {early_stop_counter}/{early_stop_patience} epochs")
            if early_stop_counter >= early_stop_patience:
                print("Early stopping triggered!")
                break
    
    # Save final model and training history
    torch.save(model.state_dict(), 'crnn_plate_recognition7.pth')
    torch.save(history, 'training_history7.pth')
    
    print(f"\n🏆 Best model at epoch {history['best_epoch']} with val loss {history['best_val_loss']:.4f}")
        # Save best model
    model_path = "best_model.pth"
    torch.save(model.state_dict(), model_path)
    print(f"[INFO] Saved best model to {model_path}")

    # Save history
    with open("history.pkl", "wb") as f:
        pickle.dump(history, f)
    print("[INFO] Training history saved to history.pkl")

    return history

# ===== Visualize Training History =====
def plot_history(history):
    plt.figure(figsize=(12, 4))
    
    # Loss curve
    plt.subplot(1, 2, 1)
    plt.plot(history['train_loss'], label='Train Loss')
    plt.plot(history['val_loss'], label='Val Loss')
    plt.title('Training and Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    
    # Accuracy curve
    plt.subplot(1, 2, 2)
    plt.plot(history['train_acc'], label='Train Acc')
    plt.plot(history['val_acc'], label='Val Acc')
    plt.title('Training and Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig('training_curve.png')
    plt.show()

def calculate_metrics(truths, preds):
    """
    Calculate various text recognition metrics
    Returns:
        dict containing:
        - char_accuracy: Character-level accuracy
        - word_accuracy: Exact match accuracy
        - cer: Character Error Rate
        - wer: Word Error Rate
        - avg_inference_time: Average inference time per sample (ms)
    """
    total_chars = 0
    correct_chars = 0
    correct_words = 0
    cer_total = 0
    wer_total = 0
    
    # Calculate character and word accuracy
    for truth, pred in zip(truths, preds):
        # Character accuracy
        min_len = min(len(truth), len(pred))
        correct_chars += sum(1 for t, p in zip(truth[:min_len], pred[:min_len]) if t == p)
        total_chars += max(len(truth), len(pred))
        
        # Word accuracy
        if truth == pred:
            correct_words += 1
    
    # Calculate CER and WER using jiwer
    measures = compute_measures(truths, preds)
    
    return {
        'char_accuracy': correct_chars / total_chars if total_chars > 0 else 0,
        'word_accuracy': correct_words / len(truths) if truths else 0,
        'cer': measures['cer'],
        'wer': measures['wer']
    }

def test():
    cfg = Config()
    model = CRNN(cfg.alphabet).to(cfg.device)
    
    model.load_state_dict(torch.load("best_model.pth", map_location=cfg.device))
    model.eval()

    transform = ResizeNormalize(cfg.img_size, augment=False)
    test_set = PlateDataset(cfg.test_dir, cfg.test_label_dir, cfg.alphabet, transform)
    test_loader = DataLoader(test_set, batch_size=cfg.batch_size, shuffle=False, collate_fn=collate_fn)

    total_correct = 0
    total_chars = 0
    test_results = []

    with torch.no_grad():
        for batch in tqdm(test_loader, desc="Testing"):
            imgs = batch['image'].to(cfg.device)
            texts = batch['text']
            outputs = model(imgs)
            pred_texts = decode(outputs, cfg.alphabet)

            for pred, truth in zip(pred_texts, texts):
                total_chars += max(len(pred), len(truth))
                total_correct += sum(1 for p, t in zip(pred, truth) if p == t)
                test_results.append((truth, pred))

    test_acc = total_correct / max(1, total_chars)
    print(f"Test Accuracy: {test_acc:.4f}")

    for i, (truth, pred) in enumerate(test_results[:10]):
        print(f"Sample {i+1}: True='{truth}', Pred='{pred}', {'Correct' if truth == pred else 'Incorrect'}")

    return test_acc, test_results


if __name__ == "__main__":
    # Train model and get history
    history = train()
    
    # Test model
    test()   
    # Visualize training process
    plot_history(history)
    
