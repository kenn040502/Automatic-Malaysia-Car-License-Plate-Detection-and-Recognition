import torch
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from my_dataset import MyCarDataset
from model import get_ssd
import random
import os

checkpoint_paths = [
    "checkpoints/ssd_epoch_0.pth",
    "checkpoints/ssd_epoch_1.pth",
    "checkpoints/ssd_epoch_2.pth",
    "checkpoints/ssd_epoch_3.pth",
    "checkpoints/ssd_epoch_4.pth",
    "checkpoints/ssd_epoch_5.pth",
    "checkpoints/ssd_epoch_6.pth",
    "checkpoints/ssd_epoch_7.pth",
    "checkpoints/ssd_epoch_8.pth",
    "checkpoints/ssd_epoch_9.pth"
    # f"checkpoints3/ssd_epoch_{i}.pth" for i in range(10, 20)
]

# Class name list (index must match predicted label values)
CLASS_NAMES = ["background", "car", "plate"]

def visualize_predictions_all_in_one():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dataset = MyCarDataset("dataset/test", "dataset/test")

    if len(dataset) < len(checkpoint_paths):
        print("❌ Not enough test images for each checkpoint")
        return

    # Random image per checkpoint
    random_indices = random.sample(range(len(dataset)), len(checkpoint_paths))

    # Prepare grid layout
    cols = 5
    rows = (len(checkpoint_paths) + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 4, rows * 4))
    axes = axes.flatten()

    for i, path in enumerate(checkpoint_paths):
        ax = axes[i]

        if not os.path.exists(path):
            ax.set_title(f"Missing: {os.path.basename(path)}")
            ax.axis('off')
            continue

        sample = dataset[random_indices[i]]
        if sample is None:
            ax.set_title(f"Invalid sample at {random_indices[i]}")
            ax.axis('off')
            continue

        img, _ = sample
        print(f"✅ Using image at index {random_indices[i]}")

        image_tensor = img.unsqueeze(0).to(device)
        img_np = img.permute(1, 2, 0).cpu().numpy()
        img_np = img_np * [0.229, 0.224, 0.225] + [0.485, 0.456, 0.406]
        img_np = img_np.clip(0, 1)

        model = get_ssd(num_classes=3)
        model.load_state_dict(torch.load(path, map_location=device))
        model.to(device)
        model.eval()

        with torch.no_grad():
            outputs = model(image_tensor)[0]

        ax.imshow(img_np)
        for box, label, score in zip(outputs['boxes'], outputs['labels'], outputs['scores']):
            if score < 0.3:
                continue

            label = int(label)
            if label >= len(CLASS_NAMES):
                print(f"⚠️ Skipping unknown label: {label}")
                continue

            box = box.cpu()
            x_min, y_min, x_max, y_max = box

            rect = patches.Rectangle(
                (x_min, y_min), x_max - x_min, y_max - y_min,
                linewidth=2, edgecolor='red', facecolor='none'
            )
            ax.add_patch(rect)
            ax.text(x_min, y_min - 5, f"{CLASS_NAMES[label]} {score:.2f}", color='red', fontsize=8)

        epoch_num = os.path.basename(path).split("_")[-1].split(".")[0]
        ax.set_title(f"Epoch {epoch_num}")
        ax.axis('off')

    # Hide unused axes
    for j in range(len(checkpoint_paths), len(axes)):
        axes[j].axis('off')

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    visualize_predictions_all_in_one()