import torch
import os

def collate_fn(batch):
    """
    Custom collate function that only filters out None entries (not empty boxes anymore).
    """
    batch = [b for b in batch if b is not None]
    if len(batch) == 0:
        return [], []
    images, targets = zip(*batch)
    return list(images), list(targets)

def save_model(model, epoch_or_path, path="checkpoints"):
    if isinstance(epoch_or_path, int):
        os.makedirs(path, exist_ok=True)
        file_path = os.path.join(path, f"ssd_epoch_{epoch_or_path}.pth")
    else:
        folder = os.path.dirname(epoch_or_path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        file_path = epoch_or_path

    torch.save(model.state_dict(), file_path)
    print(f"[INFO] Model saved: {file_path}")

def load_model(model, checkpoint_path):
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"No checkpoint found at {checkpoint_path}")
    state_dict = torch.load(checkpoint_path, map_location='cpu')
    model.load_state_dict(state_dict)
    print(f"[INFO] Model loaded from {checkpoint_path}")
    return model
