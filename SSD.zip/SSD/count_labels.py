import os
import xml.etree.ElementTree as ET
from collections import Counter

def count_labels(xml_dir):
    counter = Counter()
    for file in os.listdir(xml_dir):
        if not file.lower().endswith(".xml"):
            continue
        try:
            path = os.path.join(xml_dir, file)
            root = ET.parse(path).getroot()
            for obj in root.findall("object"):
                name = obj.find("name").text.strip().lower()
                if name == "carplate":
                    name = "plate"  # normalize to match CLASS_MAP
                counter[name] += 1
        except Exception as e:
            print(f"⚠️ Skipping {file}: {e}")
            continue
    return counter

# Run on both training and test annotation folders
print("Train labels:", count_labels("dataset/train"))
print("Test labels:", count_labels("dataset/test"))
