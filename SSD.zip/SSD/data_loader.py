from my_dataset import MyCarDataset
from torch.utils.data import DataLoader
from utils import collate_fn

def get_data_loaders(batch_size=8):
    train_dataset = MyCarDataset("dataset/train", "dataset/train")
    val_dataset = MyCarDataset("dataset/test", "dataset/test")

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, collate_fn=collate_fn)

    return train_loader, val_loader