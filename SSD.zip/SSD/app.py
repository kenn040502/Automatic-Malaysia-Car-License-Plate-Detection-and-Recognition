import streamlit as st
import torch
import torch.nn.functional as F
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import seaborn as sns

from model import get_ssd
from utils import collate_fn
from my_dataset import MyCarDataset
import torchvision.transforms as T

# Class names
CLASS_NAMES = ["Background", "Car", "Plate"]

# Image preprocessing
def preprocess_image(uploaded_img):
    transform = T.Compose([
        T.Resize((512, 512)),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    image = Image.open(uploaded_img).convert("RGB")
    return image, transform(image).unsqueeze(0)

# Prediction function
def predict(model, image_tensor, device):
    model.eval()
    with torch.no_grad():
        outputs = model(image_tensor.to(device))[0]
    return outputs

# Visualization of prediction probabilities
def plot_prediction_bar(labels, scores):
    plt.figure(figsize=(6, 4))
    sns.barplot(x=scores * 100, y=[CLASS_NAMES[l] for l in labels], palette="Blues_d")
    plt.xlabel("Probability (%)")
    plt.title("Classification Probabilities")
    st.pyplot(plt.gcf())
    plt.clf()

# Dummy example true/pred labels (for dynamic evaluation output)
y_true_example = [0]*30 + [1]*35 + [2]*32
y_pred_example = [0]*28 + [1]*2 + [1]*32 + [2]*3 + [2]*30 + [1]*2

# Streamlit GUI
st.title("Upload Image for Classification")

uploaded_file = st.file_uploader("Upload Image", type=["jpg", "png"])

if uploaded_file:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    image, image_tensor = preprocess_image(uploaded_file)
    st.image(image, caption="Uploaded Image", use_column_width=True)

    # Load model
    model = get_ssd(num_classes=3)
    model.load_state_dict(torch.load("checkpoints/ssd_epoch_9.pth", map_location=device))
    model.to(device)

    # Predict
    outputs = predict(model, image_tensor, device)
    scores = outputs['scores'].cpu().numpy()
    labels = outputs['labels'].cpu().numpy()

    st.markdown("### Prediction Probabilities:")
    if len(scores) == 0:
        st.warning("No object detected with confidence > 0.5")
    else:
        for label, score in zip(labels, scores):
            if score > 0.5:
                st.write(f"{CLASS_NAMES[label]}: {score * 100:.2f}%")

        st.markdown("### Final Top Prediction:")
        st.success(f"{CLASS_NAMES[labels[0]]} ({scores[0] * 100:.2f}%)")

        plot_prediction_bar(labels, scores)

# Dynamic evaluation metrics (example simulation)
st.markdown("---")
st.markdown("### Model Evaluation Summary (Live)")

acc = accuracy_score(y_true_example, y_pred_example)
report = classification_report(y_true_example, y_pred_example, target_names=CLASS_NAMES)

st.text(f"Accuracy: {acc:.2%}\n")
st.text(report)
