import torch
from model import get_ssd
from data_loader import get_data_loaders
from train import train_model
from utils import save_model, load_model
import os

def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # device = torch.device("cuda")
    # print("✅ Forcing GPU:", torch.cuda.get_device_name(0))

    model = get_ssd(num_classes=3).to(device)
    model_path = "checkpoints/ssd_car.pth"

    if os.path.exists(model_path):
        print("Loading existing model...")
        model = load_model(model, model_path)

    train_loader, val_loader = get_data_loaders(batch_size=16)
    train_model(model, train_loader, val_loader, device, num_epochs=50)

    # 🔽 Ensure directory exists before saving
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    save_model(model, model_path)

if __name__ == "__main__":
    main()
