
📁 SSD OBJECT DETECTION AND EVALUATION PROJECT
==============================================

This project implements a Single Shot MultiBox Detector (SSD) model for object detection 
and evaluates its performance with metrics including mAP, IoU, F1 Score, and Precision-Recall Curve.

✅ Main Features:
- Custom dataset support (Pascal VOC format: .jpg + .xml)
- SSD model built using PyTorch
- Evaluation using torchmetrics and sklearn
- Visualization of predictions and performance metrics

-------------------------------------------------
📦 REQUIREMENTS (Install Before Running)
-------------------------------------------------

1. Python 3.10+
2. Install dependencies:

   pip install -r requirements.txt

   If requirements.txt is missing, install manually:

   pip install torch torchvision torchaudio
   pip install matplotlib scikit-learn
   pip install torchmetrics
   pip install opencv-python tqdm

-------------------------------------------------
📁 PROJECT STRUCTURE
-------------------------------------------------

|-- main.py                 --> Entry point to run training/inference
|-- train.py                --> Training loop for SSD
|-- evaluate_map.py         --> Evaluate model: mAP, IoU, PR Curve, F1, etc.
|-- my_dataset.py           --> Custom dataset loader (JPEG + XML format)
|-- model.py                --> Model architecture setup
|-- utils.py                --> Utility functions (IoU calc, collate_fn, etc.)
|-- data_loader.py          --> Wrapper for training and validation DataLoader
|-- count_labels.py         --> Tool to count labels in your dataset
|-- visualize_prediction.py --> Render bounding boxes on test images
|-- app.py                  --> Optional API/Flask integration
|-- checkpoints/            --> Folder where trained model weights are saved
|-- dataset/                --> Your Pascal VOC formatted dataset
    |-- train/
    |-- test/
    |-- val/
|-- results/                --> Saved visual outputs like PR curves or loss graphs

-------------------------------------------------
🚀 GETTING STARTED
-------------------------------------------------

1. Place your dataset in the following format:

   dataset/
     ├── train/
     │    ├── images/
     │    └── labels/    (Pascal VOC .xml)
     ├── test/
     │    ├── images/
     │    └── labels/

2. To train the model:

   python train.py

3. To evaluate the model and generate metrics:

   python evaluate_map.py

   ✅ This will:
   - Load the model from `checkpoints/ssd_epoch_x.pth`
   - Print mAP, IoU, F1 Score
   - Plot Precision-Recall Curve in a pop-up window

4. To visualize predictions on test images:

   python visualize_prediction.py

-------------------------------------------------
📌 NOTES
-------------------------------------------------

- If PR curves or IoU are not showing:
   - Ensure your model is trained and checkpoint is available
   - Your test set must contain valid bounding boxes

- If you encounter an error about `torchmetrics` or `iou_threshold`:
   - Update torchmetrics:
     pip install -U torchmetrics

- To change number of classes:
   - Update the `num_classes` variable in `model.py` and `evaluate_map.py`

