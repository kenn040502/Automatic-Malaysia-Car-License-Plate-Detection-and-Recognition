import torch
from torch.utils.data import DataLoader
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, classification_report, accuracy_score
import matplotlib.pyplot as plt
import numpy as np
import os
import glob
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve
from model import get_ssd
from my_dataset import MyCarDataset
from utils import collate_fn
from torchvision.ops import box_iou

CLASS_NAMES = ["Background", "Car", "Plate"]

def evaluate_combined_confusion_matrix(checkpoint_dir="checkpoints", num_classes=3):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"📟 Using device: {device}")

    checkpoint_paths = sorted(glob.glob(os.path.join(checkpoint_dir, "ssd_epoch_*.pth")))
    if not checkpoint_paths:
        print("❌ No checkpoints found.")
        return

    test_dataset = MyCarDataset("dataset/test", "dataset/test")
    test_loader = DataLoader(test_dataset, batch_size=4, shuffle=False, collate_fn=collate_fn)

    all_y_true = []
    all_y_pred = []
    all_ious = []


    from torchmetrics.detection.mean_ap import MeanAveragePrecision
    metric = MeanAveragePrecision(iou_type="bbox", class_metrics=True)


    for path in checkpoint_paths:
        epoch_str = os.path.basename(path).split("_")[-1].split(".")[0]
        print(f"\n🔍 Evaluating Epoch {epoch_str}...")

        model = get_ssd(num_classes=num_classes)
        model.load_state_dict(torch.load(path, map_location=device))
        model.to(device)
        model.eval()

        with torch.no_grad():
            for images, targets in test_loader:
                images = [img.to(device) for img in images]
                outputs = model(images)

                # Update torchmetrics mAP metric
                outputs_cpu = [{k: v.cpu() for k, v in o.items()} for o in outputs]
                targets_cpu = [{k: v.cpu() for k, v in t.items()} for t in targets]
                metric.update(outputs_cpu, targets_cpu)


                for output, target in zip(outputs, targets):
                    gt_labels = target["labels"].cpu().numpy()
                    pred_scores = output["scores"].cpu().numpy()
                    pred_labels = output["labels"].cpu().numpy()

                    high_conf = pred_scores > 0.5
                    pred_labels = pred_labels[high_conf]

                    # 💡 IoU calculation here
                    pred_boxes = output["boxes"].cpu()
                    gt_boxes = target["boxes"].cpu()

                    if pred_boxes.size(0) > 0 and gt_boxes.size(0) > 0:
                        iou_matrix = box_iou(pred_boxes, gt_boxes)
                        for i in range(min(len(pred_boxes), len(gt_boxes))):
                            iou = iou_matrix[i].max().item()
                            all_ious.append(iou)

                    if len(gt_labels) > 0:
                        all_y_true.append(gt_labels[0])
                        if len(pred_labels) > 0:
                            all_y_pred.append(pred_labels[0])
                        else:
                            all_y_pred.append(0)

                    if len(gt_labels) > 0:
                        all_y_true.append(gt_labels[0])
                        if len(pred_labels) > 0:
                            all_y_pred.append(pred_labels[0])
                        else:
                            all_y_pred.append(0)  # Predict background

    # 1️⃣ Show Confusion Matrix
    cm = confusion_matrix(all_y_true, all_y_pred, labels=list(range(num_classes)))
    print("🔢 Confusion Matrix (raw numbers):")
    print(cm)

    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=CLASS_NAMES)
    disp.plot(cmap="Blues")
    plt.title("Confusion Matrix")
    plt.tight_layout()
    plt.show()
    input("➡️ Press Enter to continue to Classification Report...")

    # 2️⃣ Show Classification Report in Matplotlib
    report = classification_report(all_y_true, all_y_pred, target_names=CLASS_NAMES, zero_division=0)
    print("\n📊 Classification Report (raw):")
    print(report)

    plt.figure(figsize=(8, 4))
    plt.axis('off')
    plt.title("Classification Report", fontsize=14, fontweight='bold')
    plt.text(0.01, 0.5, report, {'fontsize': 10}, fontproperties='monospace')
    plt.tight_layout()
    plt.show()
    input("➡️ Press Enter to continue to Accuracy Graph...")

    # 4️⃣ Show Loss Plot
    loss_file = "checkpoints/loss_history.txt"
    if os.path.exists(loss_file):
        with open(loss_file, "r") as f:
            losses = [float(line.strip()) for line in f.readlines()]
        plt.figure()
        plt.plot(range(1, len(losses) + 1), losses, marker='o', color='blue')
        plt.title("Model Loss Over Epochs")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.grid(True)
        plt.tight_layout()
        plt.show()
    else:
        print("⚠️ Loss history file not found.")

    # 5️⃣ Show Accuracy Line Graph from file
    acc_file = "checkpoints/train_val_accuracy.txt"
    if os.path.exists(acc_file):
        import csv
        epochs, train_accs, val_accs = [], [], []
        with open(acc_file, "r") as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            for row in reader:
                epochs.append(int(row[0]))
                train_accs.append(float(row[1]))
                val_accs.append(float(row[2]))

        plt.figure()
        plt.plot(epochs, train_accs, label="Train Accuracy", marker='o')
        plt.plot(epochs, val_accs, label="Validation Accuracy", marker='s')
        plt.title("Model Accuracy Over Epochs")
        plt.xlabel("Epoch")
        plt.ylabel("Accuracy")
        plt.ylim(0, 1)
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.show()
    else:
        print("⚠️ Accuracy tracking file not found.")

    # 6️⃣ Show mAP metrics
    results = metric.compute()
    print("\n📈 mAP Evaluation Results:")
    for k, v in results.items():
        if isinstance(v, torch.Tensor):
            if v.numel() == 1:
                print(f"{k}: {v.item():.4f}")
            else:
                print(f"{k}: {[round(x.item(), 4) for x in v]}")
        else:
            print(f"{k}: {v}")

    # 7️⃣ Show IoU summary
    if all_ious:
        mean_iou = np.mean(all_ious)
        min_iou = np.min(all_ious)
        max_iou = np.max(all_ious)
        print(f"\n📐 IoU (SSD): mean={mean_iou:.4f}, range=({min_iou:.4f} – {max_iou:.4f})")
    else:
        print("⚠️ No IoU calculated. Possibly no overlapping predictions.")

     # 🎯 Plot Precision-Recall Curve (using sklearn)
    print("\n📉 Generating Precision-Recall curves using sklearn...")
    for class_id in range(1, num_classes):  # Skip background
        y_true_bin = [1 if y == class_id else 0 for y in all_y_true]
        y_pred_bin = [1 if y == class_id else 0 for y in all_y_pred]

        if sum(y_true_bin) == 0:
            print(f"⚠️ No true samples for class {CLASS_NAMES[class_id]}, skipping PR curve.")
            continue

        precision, recall, _ = precision_recall_curve(y_true_bin, y_pred_bin)
        plt.plot(recall, precision, label=f"{CLASS_NAMES[class_id]}")

    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve (from sklearn)")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    evaluate_combined_confusion_matrix()
