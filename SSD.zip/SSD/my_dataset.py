import os
import torch
from torch.utils.data import Dataset
from PIL import Image
import xml.etree.ElementTree as ET
import torchvision.transforms as T

class MyCarDataset(Dataset):
    CLASS_MAP = {
        "car": 1,
        "plate": 2
    }

    def __init__(self, image_dir, annotation_dir, transform=None):
        self.image_dir = image_dir
        self.annotation_dir = annotation_dir
        # Include both .jpg and .JPG
        self.image_filenames = [f for f in os.listdir(image_dir) if f.lower().endswith(".jpg")]
        self.transform = transform or T.Compose([
            T.Resize((512, 512)),  # Resize to SSD input size
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406],
                        std=[0.229, 0.224, 0.225]),
        ])

    def __len__(self):
        return len(self.image_filenames)

    def __getitem__(self, idx):
        filename = self.image_filenames[idx]
        img_path = os.path.join(self.image_dir, filename)
        
        # Safely replace file extension with .xml
        base_name = os.path.splitext(filename)[0]
        xml_path = os.path.join(self.annotation_dir, f"{base_name}.xml")

        try:
            img = Image.open(img_path).convert("RGB")
        except Exception as e:
            print(f"❌ Failed to load image {filename}: {e}")
            return None

        original_width, original_height = img.size
        img = self.transform(img)

        try:
            tree = ET.parse(xml_path)
            root = tree.getroot()
        except Exception as e:
            print(f"❌ Failed to parse annotation for {filename}: {e}")
            return None

        scale_x = 512 / original_width
        scale_y = 512 / original_height

        boxes, labels = [], []

        for obj in root.findall("object"):
            class_name = obj.find("name").text.strip().lower()

            # Normalize aliases like "carplate" → "plate"
            if class_name == "carplate":
                class_name = "plate"

            if class_name not in self.CLASS_MAP:
                continue  # skip unknown classes

            label = self.CLASS_MAP[class_name]

            bndbox = obj.find("bndbox")
            try:
                xmin = float(bndbox.find("xmin").text) * scale_x
                ymin = float(bndbox.find("ymin").text) * scale_y
                xmax = float(bndbox.find("xmax").text) * scale_x
                ymax = float(bndbox.find("ymax").text) * scale_y
            except Exception as e:
                print(f"⚠️ Invalid box in {filename}: {e}")
                continue

            if xmax <= xmin or ymax <= ymin:
                print(f"⚠️ Skipping invalid box in {filename}: [{xmin:.1f}, {ymin:.1f}, {xmax:.1f}, {ymax:.1f}]")
                continue
            if (xmax - xmin < 2) or (ymax - ymin < 2):
                print(f"⚠️ Skipping small box in {filename}: width={xmax - xmin:.1f}, height={ymax - ymin:.1f}")
                continue

            boxes.append([xmin, ymin, xmax, ymax])
            labels.append(label)

        if len(boxes) == 0:
            # Assign dummy full-image box for background class
            boxes.append([0.0, 0.0, 300.0, 300.0])
            labels.append(0)

        target = {
            "boxes": torch.tensor(boxes, dtype=torch.float32),
            "labels": torch.tensor(labels, dtype=torch.int64)
        }

        return img, target
