import torch
from utils import save_model
import sys

def train_model(model, train_loader, val_loader, device, num_epochs=50):
    import torch.nn.functional as F
    from sklearn.metrics import accuracy_score

    model.to(device)
    optimizer = torch.optim.SGD(
        model.parameters(), lr=0.001, momentum=0.99, weight_decay=5e-4
    )
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=15, gamma=0.1)

    epoch_losses = []
    epoch_train_acc = []
    epoch_val_acc = []

    # Clear previous loss log
    with open("checkpoints/loss_history.txt", "w") as f:
        pass

    for epoch in range(num_epochs):
        print(f"\n📘 Epoch {epoch + 1}")
        model.train()
        total_loss = 0
        correct_train = 0
        total_train = 0

        for batch_idx, batch in enumerate(train_loader):
            if batch is None or len(batch) == 0:
                print(f"⚠️ Skipping empty batch {batch_idx}")
                continue

            images, targets = batch
            images = [img.to(device) for img in images]
            targets = [{k: v.to(device) for k, v in t.items()} for t in targets]

            try:
                loss_dict = model(images, targets)
                loss = sum(loss for loss in loss_dict.values())
            except Exception as e:
                print(f"❌ Error during forward pass: {e}")
                continue

            if not torch.isfinite(loss):
                print(f"⚠️ Non-finite loss at batch {batch_idx}, skipping.")
                continue

            loss_parts = " | ".join([f"{k}: {v.item():.4f}" for k, v in loss_dict.items()])
            print(f"🔍 Batch {batch_idx} — {loss_parts}")
            print(f"✅ Total Loss: {loss.item():.4f}")

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=2.0)
            optimizer.step()

            total_loss += loss.item()

            # Approximate accuracy: 1st label per image
            model.eval()
            with torch.no_grad():
                outputs = model(images)
            model.train()

            for output, target in zip(outputs, targets):
                if target["labels"].numel() > 0 and output["labels"].numel() > 0:
                    gt = target["labels"][0].item()
                    pred = output["labels"][0].item()
                    correct_train += int(gt == pred)
                    total_train += 1

        scheduler.step()
        avg_loss = total_loss / max(1, len(train_loader))
        train_acc = correct_train / max(1, total_train)
        epoch_losses.append(avg_loss)
        epoch_train_acc.append(train_acc)

        print(f"📉 Avg Loss: {avg_loss:.4f} | 🟩 Train Accuracy: {train_acc:.2%}")
        sys.stdout.flush()

        # Validation pass
        model.eval()
        correct_val, total_val = 0, 0
        with torch.no_grad():
            for images, targets in val_loader:
                images = [img.to(device) for img in images]
                targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
                outputs = model(images)
                for output, target in zip(outputs, targets):
                    if target["labels"].numel() > 0 and output["labels"].numel() > 0:
                        gt = target["labels"][0].item()
                        pred = output["labels"][0].item()
                        correct_val += int(gt == pred)
                        total_val += 1

        val_acc = correct_val / max(1, total_val)
        epoch_val_acc.append(val_acc)
        print(f"🟦 Validation Accuracy: {val_acc:.2%}")
        sys.stdout.flush()

        save_model(model, epoch)

        # Save intermediate loss
        with open("checkpoints/loss_history.txt", "a") as f:
            f.write(f"{avg_loss}\n")

    # Save accuracy log
    with open("checkpoints/train_val_accuracy.txt", "w") as f:
        f.write("epoch,train_acc,val_acc\n")
        for i in range(num_epochs):
            f.write(f"{i+1},{epoch_train_acc[i]},{epoch_val_acc[i]}\n")

    print("✅ Training metrics saved.")