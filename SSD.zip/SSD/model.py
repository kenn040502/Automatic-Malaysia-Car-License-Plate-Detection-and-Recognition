import torchvision
import torch.nn as nn

def get_ssd(num_classes=3):
    model = torchvision.models.detection.ssd300_vgg16(weights="DEFAULT")

    # Replace classification head directly (8732 is total default anchors for SSD300)
    model.head.classification_head.num_classes = num_classes
    model.head.classification_head.cls_logits = nn.Conv2d(
        in_channels=512,  # SSD uses 512 for cls conv
        out_channels=8732 * num_classes,
        kernel_size=3,
        padding=1
    )

    return model
