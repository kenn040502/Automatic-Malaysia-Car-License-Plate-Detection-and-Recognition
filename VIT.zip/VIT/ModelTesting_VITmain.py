import os
import torch
import Levenshtein
import pandas as pd
from transformers import TrOCRProcessor, VisionEncoderDecoderModel
from PIL import Image
from jiwer import wer as jiwer_wer

# === CONFIG ===
MODEL_DIR = "trocr_plate_model"
IMAGE_FOLDER = "./test"
LABEL_FOLDER = "./test_label"
OUTPUT_CSV = "evaluation_results.csv"

# === Load model ===
device = "cuda" if torch.cuda.is_available() else "cpu"
processor = TrOCRProcessor.from_pretrained(MODEL_DIR)
model = VisionEncoderDecoderModel.from_pretrained(MODEL_DIR).to(device)

# === Helpers ===
def compute_word_acc(pred: str, gt: str) -> float:
    pred_words = pred.strip().lower().split()
    gt_words = gt.strip().lower().split()
    if not gt_words:
        return 0.0
    correct = sum(1 for p, g in zip(pred_words, gt_words) if p == g)
    return (correct / len(gt_words)) * 100

# === Results collector ===
results = []
total = 0
exact_matches = 0
char_acc_total = 0.0
cer_total = 0.0
word_acc_total = 0.0
char_wer_total = 0.0

all_preds = []
all_gts = []

print("🔍 Starting model evaluation...\n")

# === Loop through images ===
for filename in os.listdir(IMAGE_FOLDER):
    if not filename.lower().endswith((".jpg", ".jpeg", ".png")):
        continue

    base_name = os.path.splitext(filename)[0]
    image_path = os.path.join(IMAGE_FOLDER, filename)
    label_path = os.path.join(LABEL_FOLDER, base_name + ".txt")

    if not os.path.exists(label_path):
        print(f"[SKIP] No label for {filename}")
        continue

    # Load image & label
    image = Image.open(image_path).convert("RGB")
    with open(label_path, "r", encoding="utf-8") as f:
        ground_truth = f.read().strip()

    # Predict
    pixel_values = processor(images=image, return_tensors="pt").pixel_values.to(device)
    generated_ids = model.generate(pixel_values)
    prediction = processor.batch_decode(generated_ids, skip_special_tokens=True)[0].strip()

    # Normalize
    pred_norm = prediction.replace(" ", "").lower()
    gt_norm = ground_truth.replace(" ", "").lower()

    # Char-level metrics
    lev_dist = Levenshtein.distance(pred_norm, gt_norm)
    max_len = max(len(pred_norm), len(gt_norm))
    gt_len = len(gt_norm)

    char_accuracy = (1 - lev_dist / max_len) * 100 if max_len > 0 else 0.0
    cer = lev_dist / gt_len if gt_len > 0 else 1.0

    # ✅ FIXED: Use char-based WER
    pred_char_seq = " ".join(list(prediction.strip()))
    gt_char_seq = " ".join(list(ground_truth.strip()))
    char_wer = jiwer_wer(gt_char_seq, pred_char_seq) * 100

    # Word-level accuracy
    word_acc = compute_word_acc(prediction, ground_truth)

    # Match
    is_match = pred_norm == gt_norm
    total += 1
    if is_match:
        exact_matches += 1

    # Collect for summary
    all_preds.append(pred_char_seq)
    all_gts.append(gt_char_seq)

    char_acc_total += char_accuracy
    cer_total += cer
    word_acc_total += word_acc
    char_wer_total += char_wer

    print(f"{filename}: Pred = '{prediction}' | GT = '{ground_truth}' | Match = {'✅' if is_match else '❌'} | CharAcc = {char_accuracy:.2f}% | WordAcc = {word_acc:.2f}% | CER = {cer:.3f} | Char-WER = {char_wer:.2f}%")

    results.append({
        "File": filename,
        "Prediction": prediction,
        "Ground Truth": ground_truth,
        "Match": "✅" if is_match else "❌",
        "Levenshtein Distance": lev_dist,
        "Char-Level Accuracy (%)": round(char_accuracy, 2),
        "Word-Level Accuracy (%)": round(word_acc, 2),
        "CER": round(cer, 3),
        "Char-WER (%)": round(char_wer, 2)
    })

# === Save to CSV ===
df = pd.DataFrame(results)
df.to_csv(OUTPUT_CSV, index=False)
print(f"\n📁 Results saved to: {OUTPUT_CSV}")

# === Summary ===
if total > 0:
    exact_acc = (exact_matches / total) * 100
    avg_char_acc = char_acc_total / total
    avg_word_acc = word_acc_total / total
    avg_cer = cer_total / total
    avg_wer = char_wer_total / total

    print("\n====== 📊 Evaluation Summary ======")
    print(f"Total Samples              : {total}")
    print(f"Exact Matches              : {exact_matches}")
    print(f"Exact Match Accuracy       : {exact_acc:.2f}%")
    print(f"Avg Char-Level Accuracy    : {avg_char_acc:.2f}%")
    print(f"Avg Word-Level Accuracy    : {avg_word_acc:.2f}%")
    print(f"Avg CER                    : {avg_cer:.3f}")
    print(f"Avg Char-Level WER         : {avg_wer:.2f}%")

    # === Aggregate Metrics ===
    total_chars = sum(len(gt.replace(" ", "")) for gt in all_gts)
    total_correct_chars = sum(
        sum(1 for p, g in zip(pred.replace(" ", "").lower(), gt.replace(" ", "").lower()) if p == g)
        for pred, gt in zip(all_preds, all_gts)
    )

    total_words = sum(len(gt.strip().split()) for gt in all_gts)
    total_correct_words = sum(
        sum(1 for p, g in zip(pred.split(), gt.split()) if p == g)
        for pred, gt in zip(all_preds, all_gts)
    )

    agg_char_acc = (total_correct_chars / total_chars) * 100 if total_chars > 0 else 0.0
    agg_word_acc = (total_correct_words / total_words) * 100 if total_words > 0 else 0.0
    agg_cer = 1 - (total_correct_chars / total_chars) if total_chars > 0 else 1.0
    agg_wer = jiwer_wer(all_gts, all_preds) * 100

    print("\n--- Aggregate (overall) ---")
    print(f"Aggregate Char-Level Accuracy : {agg_char_acc:.2f}%")
    print(f"Aggregate Word-Level Accuracy : {agg_word_acc:.2f}%")
    print(f"Aggregate CER                 : {agg_cer:.3f}")
    print(f"Aggregate Char-Level WER      : {agg_wer:.2f}%")

else:
    print("⚠️ No valid images found for evaluation.")
