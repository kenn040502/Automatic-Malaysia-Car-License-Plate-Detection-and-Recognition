import albumentations as A
from albumentations.pytorch import ToTensorV2

# Define transform for training
train_transform = A.Compose([
    A.Resize(384, 384),
    A.RandomBrightnessContrast(p=0.3),
    A.GaussianBlur(p=0.2),
    A.Rotate(limit=5, p=0.4),
    A.Normalize(),  # important: normalize image
    ToTensorV2(),   # convert to PyTorch tensor
])

# Define transform for eval (no augmentation, just resize/normalize)
eval_transform = A.Compose([
    A.Resize(384, 384),
    A.Normalize(),
    ToTensorV2(),
])




import os
import cv2
import torch
import numpy
from PIL import Image
from transformers import (
    TrOCRProcessor,
    VisionEncoderDecoderModel,
    Seq2SeqTrainer,
    Seq2SeqTrainingArguments,
    TrainerCallback,
    default_data_collator
)

training_args = Seq2SeqTrainingArguments(
    output_dir="./trocr_plate_output",
    per_device_train_batch_size=4,
    per_device_eval_batch_size=4,
    logging_dir="./logs",
    eval_strategy="steps",
    save_strategy="steps",
    save_steps=500,
    eval_steps=500,
    num_train_epochs=20,
    logging_steps=100,
    learning_rate=3e-5,
    load_best_model_at_end=True,
    metric_for_best_model="eval_loss",
    greater_is_better=False,
    predict_with_generate=True,
    generation_max_length=32,  # Match your max plate length
    generation_num_beams=5,  # During evaluation
    eval_accumulation_steps=1,  # Better memory management
    warmup_ratio=0.1,  # More gradual learning
    weight_decay=0.01  # Regularization
)

from torch.utils.data import Dataset

class PredictionCallback(TrainerCallback):
    def __init__(self, processor, eval_dataset, num_samples=3):
        self.processor = processor
        self.eval_dataset = eval_dataset
        self.num_samples = num_samples

    def on_evaluate(self, args, state, control, **kwargs):
        model = kwargs['model']
        indices = torch.randperm(len(self.eval_dataset))[:self.num_samples]

        print("\nSample Predictions:")
        for idx in indices:
            sample = self.eval_dataset[idx]
            pixel_values = sample["pixel_values"].unsqueeze(0).to(model.device)

            generated_ids = model.generate(
                pixel_values,
                max_length=32,
                num_beams=5,
                early_stopping=False,
                length_penalty=1.5,
            )

            pred_text = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]

            label_ids = sample["labels"]
            label_ids = label_ids[label_ids != -100]
            true_text = self.processor.tokenizer.decode(label_ids, skip_special_tokens=True)

            print(f"Sample {idx}: Predict='{pred_text}' | Actual='{true_text}'")


class PlateDataset(Dataset):
    def __init__(self, root_dir, processor, max_target_length=32, transform=None):
        self.root_dir = root_dir
        self.image_paths = [os.path.join(root_dir, f) for f in os.listdir(root_dir) if f.endswith((".jpg", ".png"))]
        self.processor = processor
        self.max_target_length = max_target_length
        self.transform = transform

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        image_path = self.image_paths[idx]

        # Read image with OpenCV
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Convert to PIL Image (processor expects this)
        image = Image.fromarray(image)

        # Prepare label with eos token
        label = os.path.basename(image_path).split(".")[0].strip()
        label = label.split("(")[0].strip()  # Remove (1), (2), etc.
        label += self.processor.tokenizer.eos_token

        encoding = self.processor(
            images=image,
            text=label,
            return_tensors="pt",
            padding="max_length",
            max_length=self.max_target_length,
            truncation=True,
        )

        labels = encoding["labels"].squeeze()
        labels[labels == self.processor.tokenizer.pad_token_id] = -100

        return {
            "pixel_values": encoding["pixel_values"].squeeze(),
            "labels": labels
        }


def main():
    processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-printed")
    model = VisionEncoderDecoderModel.from_pretrained("microsoft/trocr-base-printed")
    model.config.decoder_start_token_id = processor.tokenizer.bos_token_id
    model.config.pad_token_id = processor.tokenizer.pad_token_id

    train_dataset = PlateDataset("train", processor, max_target_length=32)
    eval_dataset = PlateDataset("val", processor, max_target_length=32)
    test_dataset = PlateDataset("test", processor, max_target_length=32)

    training_args = Seq2SeqTrainingArguments(
        output_dir="./trocr_plate_output",
        per_device_train_batch_size=4,
        per_device_eval_batch_size=4,
        eval_strategy="steps",
        save_strategy="steps",
        num_train_epochs=10,
        fp16=True,
        logging_strategy="steps",
        logging_steps=100,
        logging_dir="./logs",
        learning_rate=3e-5,
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        predict_with_generate=True,
        generation_max_length=32,  # Match your max plate length
        generation_num_beams=5,  # During evaluation
        eval_accumulation_steps=1,  # Better memory management
        warmup_steps=300,
        save_steps=500,
        report_to="none",
        save_total_limit=2,
        weight_decay=0.01,
        gradient_accumulation_steps=2,
    )

    pred_callback = PredictionCallback(processor, eval_dataset, num_samples=3)

    class LossLoggingCallback(TrainerCallback):
        def on_log(self, args, state, control, logs=None, **kwargs):
            if logs is not None and "loss" in logs:
                print(f"Step {state.global_step}\tLoss: {logs['loss']:.6f}")

    trainer = Seq2SeqTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=lambda x: {
            "pixel_values": torch.stack([item["pixel_values"] for item in x]),
            "labels": torch.nn.utils.rnn.pad_sequence(
                [item["labels"] for item in x],
                batch_first=True,
                padding_value=processor.tokenizer.pad_token_id
            )
        },
        callbacks=[pred_callback, LossLoggingCallback()]
    )

    # Train the model without validation
    trainer.train()

    # Save model and processor
    trainer.save_model("trocr_plate_model_complete")
    processor.save_pretrained("trocr_plate_model_complete")
    print("Model saved ")

    # --- Testing step: Evaluate model on test dataset ---
    model.eval()
    model.to(trainer.args.device)

    correct = 0
    total = len(test_dataset)

    for i in range(total):
        sample = test_dataset[i]
        pixel_values = sample["pixel_values"].unsqueeze(0).to(trainer.args.device)

        with torch.no_grad():
            generated_ids = model.generate(pixel_values, max_length=32, num_beams=5)
        pred_text = processor.batch_decode(generated_ids, skip_special_tokens=True)[0]

        label_ids = sample["labels"]
        label_ids = label_ids[label_ids != -100]
        true_text = processor.tokenizer.decode(label_ids, skip_special_tokens=True)

        if pred_text.strip().upper() == true_text.strip().upper():  # Normalize texts before comparison
            correct += 1

        if i < 5:  # Print first 5 predictions as samples
            print(f"Sample {i}: Predict='{pred_text}' | Actual='{true_text}'")

    accuracy = correct / total
    print(f"Test accuracy: {accuracy:.4f}")


if __name__ == "__main__":
    main()