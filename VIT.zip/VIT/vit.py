# vit.py - TrOCR Fine-Tuning for OCR Dataset with Label Text Files

import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
import cv2
import torch
from PIL import Image
from transformers import (
    TrOCRProcessor,
    VisionEncoderDecoderModel,
    Seq2SeqTrainer,
    Seq2SeqTrainingArguments,
    TrainerCallback
)
import albumentations as A
from albumentations.pytorch import ToTensorV2
from torch.utils.data import Dataset
from tqdm import tqdm

# --- Transforms ---
train_transform = A.Compose([
    A.Resize(256, 256),
    A.RandomBrightnessContrast(p=0.3),
    A.GaussianBlur(p=0.2),
    A.Rotate(limit=5, p=0.4),
    A.Normalize(),
    ToTensorV2(),
])
eval_transform = A.Compose([
    A.Resize(256, 256),
    A.Normalize(),
    ToTensorV2(),
])

# --- Dataset Class ---
class PlateDataset(Dataset):
    def __init__(self, root_dir, label_dir, processor, max_target_length=32):
        self.root_dir = root_dir
        self.label_dir = label_dir
        self.processor = processor
        self.max_target_length = max_target_length

        if not os.path.exists(root_dir):
            raise FileNotFoundError(f"Image directory not found: {root_dir}")
        if not os.path.exists(label_dir):
            raise FileNotFoundError(f"Label directory not found: {label_dir}")

        self.image_paths = sorted([
            os.path.join(root_dir, f)
            for f in os.listdir(root_dir)
            if f.lower().endswith(('.jpg', '.png'))
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        image_path = self.image_paths[idx]
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image = Image.fromarray(image)

        base_name = os.path.basename(image_path).split('.')[0]
        label_path = os.path.join(self.label_dir, base_name + ".txt")

        if os.path.exists(label_path):
            with open(label_path, 'r', encoding='utf-8') as f:
                label = f.read().strip()
        else:
            label = ""

        label += self.processor.tokenizer.eos_token

        encoding = self.processor(
            images=image,
            text=label,
            return_tensors="pt",
            padding="max_length",
            max_length=self.max_target_length,
            truncation=True,
        )

        labels = encoding["labels"].squeeze()
        labels[labels == self.processor.tokenizer.pad_token_id] = -100

        return {
            "pixel_values": encoding["pixel_values"].squeeze(),
            "labels": labels
        }

# --- Callback to show predictions ---
class PredictionCallback(TrainerCallback):
    def __init__(self, processor, eval_dataset, num_samples=3):
        self.processor = processor
        self.eval_dataset = eval_dataset
        self.num_samples = num_samples

    def on_evaluate(self, args, state, control, **kwargs):
        model = kwargs['model']
        indices = torch.randperm(len(self.eval_dataset))[:self.num_samples]
        for idx in indices:
            item = self.eval_dataset[idx]
            pixel_values = item["pixel_values"].unsqueeze(0).to(model.device)

            with torch.no_grad():
                generated_ids = model.generate(pixel_values)
            predicted_text = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
            print(f"[Eval Prediction] Sample {idx} => {predicted_text}")

# --- Custom Logging Callback like YOLO ---
class ProgressLoggerCallback(TrainerCallback):
    def on_log(self, args, state, control, logs=None, **kwargs):
        if logs is None or 'loss' not in logs:
            return
        loss = logs.get("loss", 0)
        lr = logs.get("learning_rate", 0)
        epoch = logs.get("epoch", 0)
        step = state.global_step
        print(f"📊 Epoch {epoch:.2f} | Step {step} | Loss: {loss:.4f} | LR: {lr:.2e}")

# --- Main ---
def main():
    from transformers import logging
    logging.set_verbosity_error()

    print(f"🔥 CUDA Available: {torch.cuda.is_available()}")
    print(f"🔥 GPU Name: {torch.cuda.get_device_name(0)}" if torch.cuda.is_available() else "")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🖥️ Using device: {device}")

    processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-printed")
    model = VisionEncoderDecoderModel.from_pretrained("microsoft/trocr-base-printed")

    model.config.decoder_start_token_id = processor.tokenizer.bos_token_id
    model.config.pad_token_id = processor.tokenizer.pad_token_id
    model = model.to(device)

    base_path = "./"
    train_img_dir = os.path.join(base_path, "train")
    train_label_dir = os.path.join(base_path, "train_label")
    test_img_dir = os.path.join(base_path, "test")
    test_label_dir = os.path.join(base_path, "test_label")

    train_dataset = PlateDataset(train_img_dir, train_label_dir, processor)
    test_dataset = PlateDataset(test_img_dir, test_label_dir, processor)

    output_dir = "./vit_output"
    os.makedirs(output_dir, exist_ok=True)

    training_args = Seq2SeqTrainingArguments(
        output_dir=output_dir,
        per_device_train_batch_size=4,
        per_device_eval_batch_size=2,
        predict_with_generate=True,
        logging_dir=os.path.join(output_dir, "logs"),
        logging_strategy="steps",
        logging_steps=5,
        save_strategy="no",
        num_train_epochs=2,
        report_to="none",
        do_train=True,
        do_eval=True,
        eval_steps=10,
    )

    trainer = Seq2SeqTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=test_dataset,
        tokenizer=processor,
        callbacks=[
            PredictionCallback(processor, test_dataset),
            ProgressLoggerCallback()
        ]
    )

    trainer.train()
    model.save_pretrained(os.path.join(output_dir, "final_model"))
    processor.save_pretrained(os.path.join(output_dir, "final_processor"))
    print("✅ Training complete and model saved.")

if __name__ == "__main__":
    main()
