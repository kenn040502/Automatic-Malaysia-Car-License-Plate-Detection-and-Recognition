from ultralytics import YOLO
import json
import argparse
import os


def run_test_and_save(
    model_path: str,
    data_yaml: str,
    out_json: str = "runs/val/metrics.json",
    imgsz: int = 640,
    batch: int = 16,
    iou: float = 0.5
):
    """
    1) Loads a trained YOLO model from `model_path`
    2) Runs validation on the 'val' split in `data_yaml`
    3) Saves metrics.results_dict to `out_json`
    """
    # Load model
    model = YOLO(model_path)

    # Run validation
    metrics = model.val(
        data=data_yaml,
        imgsz=imgsz,
        batch=batch,
        iou=iou
    )

    # Extract and save
    results = metrics.results_dict
    os.makedirs(os.path.dirname(out_json) or ".", exist_ok=True)
    with open(out_json, "w") as f:
        json.dump(results, f, indent=2)
    print(f"✅ Metrics saved to {out_json}")
    return metrics


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Run YOLO validation and dump metrics to JSON."
    )
    # provide sensible defaults so flags are optional
    parser.add_argument(
        "--model",
        default=r"D:\Programming\2025 Sem1\Intelligent System\Program\program\runs\train\yolov8_model10\weights\best.pt",
        help="path to best.pt or last.pt (default: best.pt)"
    )
    parser.add_argument(
        "--data",
        default=r"D:\Programming\2025 Sem1\Intelligent System\Program\program\dataset\dataset.yaml",
        help="path to dataset.yaml (default: data.yaml)"
    )
    parser.add_argument(
        "--out",
        default="runs/val/metrics.json",
        help="where to save the metrics JSON"
    )
    parser.add_argument(
        "--imgsz",
        type=int,
        default=640,
        help="image size for validation (default: 640)"
    )
    parser.add_argument(
        "--batch",
        type=int,
        default=16,
        help="batch size for validation (default: 16)"
    )
    parser.add_argument(
        "--iou",
        type=float,
        default=0.5,
        help="IoU threshold for metrics (default: 0.5)"
    )
    args = parser.parse_args()

    run_test_and_save(
        model_path=args.model,
        data_yaml=args.data,
        out_json=args.out,
        imgsz=args.imgsz,
        batch=args.batch,
        iou=args.iou
    )
