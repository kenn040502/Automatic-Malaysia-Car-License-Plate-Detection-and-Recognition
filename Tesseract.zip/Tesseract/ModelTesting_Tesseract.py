import os
import cv2
import numpy as np
import pytesseract
import Levenshtein
import pandas as pd
from jiwer import wer as jiwer_wer

# === CONFIG ===
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
image_folder = r"D:\Programming\2025 Sem1\Intelligent System\Program\Jewel\Latest\OCR_Dataset\test"
label_folder = r"D:\Programming\2025 Sem1\Intelligent System\Program\Jewel\Latest\OCR_Dataset\test_label"
output_csv = "tesseract_results.csv"

def preprocess(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.medianBlur(gray, 3)
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return thresh

def compute_word_acc(prediction: str, ground_truth: str) -> float:
    pred_words = prediction.strip().lower().split()
    gt_words = ground_truth.strip().lower().split()
    if not gt_words:
        return 0.0
    correct = sum(1 for p, g in zip(pred_words, gt_words) if p == g)
    return (correct / len(gt_words)) * 100

# === Stats ===
results = []
total = 0
exact_match = 0

char_acc_total = 0.0
cer_total = 0.0
wer_total = 0.0
word_acc_total = 0.0

total_correct_chars = 0
total_chars = 0
total_correct_words = 0
total_words = 0

all_preds = []
all_gts = []

print("🔍 Starting Tesseract model evaluation...\n")

for filename in os.listdir(image_folder):
    if not filename.lower().endswith(".jpg"):
        continue

    base_name = os.path.splitext(filename)[0]
    image_path = os.path.join(image_folder, filename)
    label_path = os.path.join(label_folder, base_name + ".txt")

    if not os.path.exists(label_path):
        print(f"[SKIP] Missing label for {filename}")
        continue

    img = cv2.imread(image_path)
    if img is None:
        print(f"[Error] Cannot read image: {filename}")
        continue

    with open(label_path, "r", encoding="utf-8") as f:
        ground_truth = f.read().strip()

    processed_img = preprocess(img)
    ocr_result = pytesseract.image_to_string(processed_img).strip()

    # Append only valid pairs
    all_preds.append(ocr_result)
    all_gts.append(ground_truth)

    pred_norm = ocr_result.replace(" ", "").lower()
    gt_norm = ground_truth.replace(" ", "").lower()

    total += 1
    is_match = pred_norm == gt_norm
    if is_match:
        exact_match += 1

    lev_dist = Levenshtein.distance(pred_norm, gt_norm)
    max_len = max(len(pred_norm), len(gt_norm))
    gt_len = len(gt_norm)

    char_accuracy = (1 - lev_dist / max_len) * 100 if max_len > 0 else 0
    cer = (lev_dist / gt_len) if gt_len > 0 else 1.0

    # ✅ FIXED: Use char-based WER instead of word-based
    actual_wer = jiwer_wer(" ".join(list(ground_truth.strip())), " ".join(list(ocr_result.strip())))
    word_acc = compute_word_acc(ocr_result, ground_truth)

    char_acc_total += char_accuracy
    cer_total += cer
    wer_total += actual_wer
    word_acc_total += word_acc

    total_chars += max_len
    total_correct_chars += sum(1 for p, t in zip(pred_norm, gt_norm) if p == t)

    gt_words = ground_truth.strip().split()
    pred_words = ocr_result.strip().split()
    total_words += len(gt_words)
    total_correct_words += sum(1 for p, g in zip(pred_words, gt_words) if p == g)

    print(f"{filename} → OCR: '{ocr_result}' | GT: '{ground_truth}' | Match: {'✅' if is_match else '❌'} | CharAcc: {char_accuracy:.2f}% | WordAcc: {word_acc:.2f}% | CER: {cer:.3f} | WER: {actual_wer*100:.3f}%")

    results.append({
        "File": filename,
        "Prediction": ocr_result,
        "Ground Truth": ground_truth,
        "Match": "✅" if is_match else "❌",
        "Levenshtein Distance": lev_dist,
        "Char-Level Accuracy (%)": round(char_accuracy, 2),
        "Word-Level Accuracy (%)": round(word_acc, 2),
        "CER": round(cer, 3),
        "WER (%)": round(actual_wer * 100, 3)
    })

# Save CSV
df = pd.DataFrame(results)
df.to_csv(output_csv, index=False)
print(f"\n📁 Results saved to {output_csv}")

# Final Summary
if total > 0:
    exact_acc = (exact_match / total) * 100
    avg_char_acc = char_acc_total / total
    avg_word_acc = word_acc_total / total
    avg_cer = cer_total / total
    avg_wer = wer_total / total * 100

    agg_char_acc = (total_correct_chars / max(1, total_chars)) * 100
    agg_word_acc = (total_correct_words / max(1, total_words)) * 100
    agg_cer = 1 - (total_correct_chars / max(1, total_chars))

    # ✅ FIXED: Char-based aggregate WER
    agg_wer_jiwer = jiwer_wer(
        [" ".join(list(gt.strip())) for gt in all_gts],
        [" ".join(list(pred.strip())) for pred in all_preds]
    ) * 100

    print("\n====== 📊 Tesseract Evaluation Summary ======")
    print(f"Total Samples                 : {total}")
    print(f"Exact Matches                 : {exact_match}")
    print(f"Exact Match Accuracy          : {exact_acc:.2f}%")

    print("\n--- Average (per sample) ---")
    print(f"Avg Char-Level Accuracy       : {avg_char_acc:.2f}%")
    print(f"Avg Word-Level Accuracy       : {avg_word_acc:.2f}%")
    print(f"Avg CER                       : {avg_cer:.3f}")
    print(f"Avg WER                       : {avg_wer:.3f}%")

    print("\n--- Aggregate (overall) ---")
    print(f"Aggregate Char-Level Accuracy : {agg_char_acc:.2f}%")
    print(f"Aggregate Word-Level Accuracy : {agg_word_acc:.2f}%")
    print(f"Aggregate CER                 : {agg_cer:.3f}")
    print(f"Aggregate WER (jiwer)         : {agg_wer_jiwer:.3f}%")
else:
    print("⚠️ No valid images found.")
