import cv2
import pytesseract
import os

def preprocess(image):
    # Convert the image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # Apply median blur for noise removal
    gray = cv2.medianBlur(gray, 3)
    # Apply Otsu's thresholding method
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return thresh

# Folder with images and ground truth
image_folder = r"C:/Users/JEWEL/OneDrive - Asia Pacific University/Desktop/Swinburne/Intellig/Filtered_DataSet2/tessdata/train"

for filename in os.listdir(image_folder):
    if filename.lower().endswith(".jpg"):
        base_name = os.path.splitext(filename)[0]
        img_path = os.path.join(image_folder, filename)
        gt_path = os.path.join(image_folder, base_name + ".gt.txt")

        # Read image and ground truth
        img = cv2.imread(img_path)
        with open(gt_path, 'r', encoding='utf-8') as f:
            ground_truth = f.read().strip()  # Strip any unwanted leading or trailing spaces/newlines

        if img is None:
            print(f"Cannot read image {filename}")
            continue

        # Preprocess the image
        processed = preprocess(img)
        # Perform OCR
        ocr_result = pytesseract.image_to_string(processed).strip()

        # Compare and print OCR result with ground truth
        print(f"{filename} → OCR: '{ocr_result}' | GT: '{ground_truth}'")
